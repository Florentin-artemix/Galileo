package com.galileo.ecriture.service;

import com.galileo.ecriture.dto.UserDTO;
import com.galileo.ecriture.entity.User;
import com.galileo.ecriture.repository.UserRepository;
import com.galileo.ecriture.security.Role;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service pour la gestion des utilisateurs Firebase
 */
@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    
    private final UserRepository userRepository;
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Lister tous les utilisateurs depuis PostgreSQL
     * Plus besoin de Firebase Admin SDK - fonctionne sans compte de facturation
     */
    public List<UserDTO> listerUtilisateurs() {
        try {
            List<User> users = userRepository.findAll();
            logger.info("Récupération réussie de {} utilisateurs depuis PostgreSQL", users.size());
            return users.stream()
                    .map(this::convertToDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Erreur lors de la récupération des utilisateurs depuis PostgreSQL", e);
            throw new RuntimeException("Impossible de récupérer les utilisateurs: " + e.getMessage());
        }
    }

    /**
     * Obtenir un utilisateur par UID depuis PostgreSQL
     */
    public UserDTO obtenirUtilisateur(String uid) {
        try {
            User user = userRepository.findByUid(uid)
                    .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé: " + uid));
            return convertToDTO(user);
        } catch (Exception e) {
            logger.error("Utilisateur non trouvé: {}", uid, e);
            throw new RuntimeException("Utilisateur non trouvé: " + uid);
        }
    }

    /**
     * Obtenir ou créer un profil utilisateur pour l'utilisateur courant (headers X-User-Id/X-User-Email)
     */
    @Transactional
    public UserDTO obtenirProfil(String uid, String email, String roleHeader) {
        if (uid == null || uid.isEmpty()) {
            throw new RuntimeException("UID requis");
        }

        User user = userRepository.findByUid(uid)
                .orElseGet(() -> {
                    User nouveau = new User();
                    nouveau.setUid(uid);
                    nouveau.setEmail(email != null ? email : "");
                    Role headerRole = parseRole(roleHeader);
                    nouveau.setRole(headerRole != null ? headerRole : Role.VIEWER);
                    nouveau.setCreationTime(LocalDateTime.now());
                    nouveau.setDisabled(false);
                    return nouveau;
                });

        if (email != null && !email.isBlank() && !email.equalsIgnoreCase(user.getEmail())) {
            user.setEmail(email);
        }

        // Si le header rôle est présent et plus précis, synchroniser
        Role headerRole = parseRole(roleHeader);
        if (headerRole != null && headerRole != user.getRole()) {
            user.setRole(headerRole);
            logger.info("Synchronisation rôle {} -> {} pour {}", user.getRole(), headerRole, uid);
        }

        user.setLastSignInTime(LocalDateTime.now());

        userRepository.save(user);
        return convertToDTO(user);
    }

    /**
     * Modifier le rôle d'un utilisateur (via Firebase custom claims et PostgreSQL)
     */
    @Transactional
    public void modifierRole(String uid, Role role) {
        try {
            if (!FirebaseApp.getApps().isEmpty()) {
                try {
                    Map<String, Object> claims = new HashMap<>();
                    claims.put("role", role.name());
                    FirebaseAuth.getInstance().setCustomUserClaims(uid, claims);
                    logger.info("Rôle {} attribué à l'utilisateur {} dans Firebase", role, uid);

                    FirebaseAuth.getInstance().revokeRefreshTokens(uid);
                    logger.info("Tokens révoqués pour l'utilisateur {} - il devra se reconnecter", uid);
                } catch (FirebaseAuthException e) {
                    logger.warn("Impossible de modifier le rôle dans Firebase: {}", e.getMessage());
                }
            }

            User user = userRepository.findByUid(uid)
                    .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé: " + uid));
            user.setRole(role);
            userRepository.save(user);
            logger.info("Rôle {} mis à jour pour l'utilisateur {} dans PostgreSQL", role, uid);

        } catch (Exception e) {
            logger.error("Erreur lors de la modification du rôle de {}", uid, e);
            throw new RuntimeException("Impossible de modifier le rôle: " + e.getMessage());
        }
    }

    /**
     * Attribuer le rôle initial lors de l'inscription (sans révoquer les tokens)
     * Synchronise également l'utilisateur dans PostgreSQL avec les métadonnées
     */
    @Transactional
    public void attribuerRoleInitial(String uid, String email, String displayName, String program, String motivation, Role role) {
        try {
            if (!FirebaseApp.getApps().isEmpty()) {
                try {
                    Map<String, Object> claims = new HashMap<>();
                    claims.put("role", role.name());
                    FirebaseAuth.getInstance().setCustomUserClaims(uid, claims);
                    logger.info("Rôle initial {} attribué à l'utilisateur {} dans Firebase", role, uid);
                } catch (FirebaseAuthException e) {
                    logger.warn("Impossible d'attribuer le rôle dans Firebase: {}", e.getMessage());
                }
            }

            User user = userRepository.findByUid(uid).orElse(new User());
            user.setUid(uid);
            user.setEmail(email != null ? email : "");
            user.setDisplayName(displayName);
            user.setProgram(program);
            user.setMotivation(motivation);
            user.setRole(role);
            user.setDisabled(false);
            if (user.getCreationTime() == null) {
                user.setCreationTime(LocalDateTime.now());
            }

            userRepository.save(user);
            logger.info("Utilisateur {} synchronisé dans PostgreSQL avec rôle {}", uid, role);

        } catch (Exception e) {
            logger.error("Erreur lors de l'attribution du rôle initial pour {}", uid, e);
            throw new RuntimeException("Impossible d'attribuer le rôle initial: " + e.getMessage());
        }
    }

    /**
     * Mettre à jour le profil utilisateur (imageUrl, displayName, motivation)
     */
    @Transactional
    public UserDTO mettreAJourProfil(String uid, String email, String imageUrl, String name, String motivation) {
        User user = userRepository.findByUid(uid)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé: " + uid));
        
        if (imageUrl != null) {
            user.setImageUrl(imageUrl);
        }
        if (name != null && !name.isBlank()) {
            user.setDisplayName(name);
        }
        if (motivation != null) {
            user.setMotivation(motivation);
        }
        
        userRepository.save(user);
        logger.info("Profil mis à jour pour user: {} (imageUrl: {})", uid, imageUrl != null ? "oui" : "non");
        
        return convertToDTO(user);
    }

    /**
     * Convertir un User (PostgreSQL) en UserDTO
     */
    private UserDTO convertToDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setUid(user.getUid());
        dto.setEmail(user.getEmail());
        dto.setDisplayName(user.getDisplayName());
        dto.setProgram(user.getProgram());
        dto.setMotivation(user.getMotivation());
        dto.setImageUrl(user.getImageUrl());
        dto.setDisabled(user.getDisabled() != null ? user.getDisabled() : false);
        dto.setRole(user.getRole());

        if (user.getCreationTime() != null) {
            dto.setCreationTime(String.valueOf(user.getCreationTime().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()));
        }
        if (user.getLastSignInTime() != null) {
            dto.setLastSignInTime(String.valueOf(user.getLastSignInTime().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()));
        }

        return dto;
    }

    private Role parseRole(String roleHeader) {
        if (roleHeader == null || roleHeader.isBlank()) return null;
        try {
            return Role.valueOf(roleHeader.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /**
     * Récupérer tous les membres de l'équipe (STAFF + ADMIN) pour la page publique
     */
    public List<UserDTO> getTeamMembers() {
        List<User> teamMembers = userRepository.findByRoleIn(List.of(Role.STAFF, Role.ADMIN));
        logger.info("Récupération de {} membres d'équipe (STAFF + ADMIN)", teamMembers.size());
        return teamMembers.stream()
                .filter(u -> !Boolean.TRUE.equals(u.getDisabled()))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Récupérer les utilisateurs par rôle
     */
    public List<UserDTO> getUsersByRole(String roleStr) {
        try {
            Role role = Role.valueOf(roleStr.toUpperCase());
            List<User> users = userRepository.findByRole(role);
            return users.stream()
                    .filter(u -> !Boolean.TRUE.equals(u.getDisabled()))
                    .map(this::convertToDTO)
                    .collect(Collectors.toList());
        } catch (IllegalArgumentException e) {
            logger.warn("Rôle invalide: {}", roleStr);
            return List.of();
        }
    }
}
