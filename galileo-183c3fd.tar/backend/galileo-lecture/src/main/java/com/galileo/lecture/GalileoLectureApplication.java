package com.galileo.lecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GalileoLectureApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(GalileoLectureApplication.class, args);
    }
}
